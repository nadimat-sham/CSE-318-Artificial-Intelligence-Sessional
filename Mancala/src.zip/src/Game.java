public interface Game {
    void play();
}
